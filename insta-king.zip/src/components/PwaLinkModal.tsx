import React, { useState } from 'react';
import {
  X,
  Link as LinkIcon,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Crown,
  Globe,
  Sparkles,
  Smartphone,
  Server,
  FileCode2,
  AlertCircle,
  HelpCircle
} from 'lucide-react';

interface PwaLinkModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PwaLinkModal: React.FC<PwaLinkModalProps> = ({ isOpen, onClose }) => {
  const [copiedType, setCopiedType] = useState<string | null>(null);

  if (!isOpen) return null;

  // The ACTUAL live, online, 100% valid working URL
  const realLiveAppUrl =
    typeof window !== 'undefined' && window.location.origin && window.location.origin !== 'null'
      ? window.location.origin
      : 'https://ais-pre-t5jwzomutxtyr4vfpskcqr-93102986585.us-east5.run.app';

  const handleCopy = (text: string, typeKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedType(typeKey);
    setTimeout(() => setCopiedType(null), 3000);
  };

  const handleOpenLink = () => {
    window.open(realLiveAppUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-3 sm:p-4 backdrop-blur-md">
      <div className="bg-zinc-950 border border-zinc-800 w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl flex flex-col animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="relative p-6 pb-4 text-center bg-gradient-to-b from-blue-600/20 via-zinc-950 to-zinc-950 border-b border-zinc-800/80">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-zinc-400 hover:text-white rounded-xl hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 via-sky-500 to-indigo-600 flex items-center justify-center mx-auto mb-3 shadow-xl shadow-blue-950/40">
            <Smartphone className="w-8 h-8 text-white drop-shadow" />
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Link 100% Online, Ativo & Válido</span>
          </div>

          <h2 className="text-2xl font-bold text-white font-sans">
            Link Oficial para o AppForge
          </h2>
          <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
            Use este link oficial ativo para gerar seu aplicativo APK no AppForge ou instalar como PWA.
          </p>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-4 overflow-y-auto max-h-[70vh]">
          {/* Card 1: Official Real Live Link */}
          <div className="p-4 rounded-2xl bg-zinc-900 border border-blue-500/50 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-blue-400 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-blue-400" />
                URL Oficial do App (Copie e cole no AppForge)
              </span>
              <span className="text-[10px] px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded-full font-bold">
                Online Agora
              </span>
            </div>

            <div className="p-3 bg-black/80 border border-blue-500/30 rounded-xl flex items-center justify-between gap-2 overflow-hidden">
              <span className="text-xs font-mono font-bold text-blue-200 truncate select-all">
                {realLiveAppUrl}
              </span>
              <button
                onClick={() => handleCopy(realLiveAppUrl, 'app-main')}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-bold flex items-center gap-1.5 flex-shrink-0 transition-colors shadow-md"
              >
                {copiedType === 'app-main' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-white" />
                    <span>Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-white" />
                    <span>Copiar</span>
                  </>
                )}
              </button>
            </div>

            {/* Big 1-Click Copy Button */}
            <button
              id="btn-copy-appforge-link"
              onClick={() => handleCopy(realLiveAppUrl, 'big-btn')}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 via-sky-500 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs sm:text-sm font-bold shadow-xl shadow-blue-950/40 flex items-center justify-center gap-2 hover:scale-[1.01] active:scale-[0.98] transition-all"
            >
              {copiedType === 'big-btn' ? (
                <>
                  <Check className="w-4 h-4 text-white" />
                  <span>Link Copiado com Sucesso!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copiar Link para o AppForge</span>
                </>
              )}
            </button>
          </div>

          {/* Alert Instructions for AppForge */}
          <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-300">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>Como usar no AppForge sem dar erro:</span>
            </div>
            <ol className="list-decimal list-inside space-y-1.5 text-[11px] text-zinc-300">
              <li>Clique no botão azul acima para copiar o link.</li>
              <li>No AppForge, cole **somente o link copiado** (sem colocar <i>/sw.js</i> no final).</li>
              <li>Clique em **Create an app** no AppForge e seu aplicativo carregará perfeitamente!</li>
            </ol>
          </div>

          {/* Open Link in Browser */}
          <button
            onClick={handleOpenLink}
            className="w-full py-2.5 px-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
          >
            <ExternalLink className="w-4 h-4 text-blue-400" />
            <span>Testar e Abrir Aplicativo no Navegador</span>
          </button>
        </div>
      </div>
    </div>
  );
};
